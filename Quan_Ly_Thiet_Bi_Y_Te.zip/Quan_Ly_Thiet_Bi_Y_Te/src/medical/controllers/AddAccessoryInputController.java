/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * AddUserController.java, Aug 10, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Accessory;
import medical.entities.Provider;
import medical.logics.ProviderLogicImpl;
import medical.utils.Common;
import medical.utils.Constants;
import medical.validates.AccessoryValidate;

/**
 * 
 * Controller để xử lý cho màn hình ADM003 trường hợp add
 *
 * @author namlh
 *
 */
public class AddAccessoryInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo đối tượng UserInfor
			Accessory accessory = new Accessory();
			// Set giá trị cho các hạng mục selectbox ở màn hình ADM003
			setDataLogic(request);
			// Lấy userInfor
			accessory = getDefaultValue(request);
			// set userInfor vừa lấy được lên request
			request.setAttribute("accessory", accessory);
			// Forward đến trang ADM003
			RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_ACCESSORY_JSP);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 *
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
//			 Khởi tạo list chứa các câu thông báo lỗi validate
			List<String> listErrorMess = new ArrayList<>();
			// Khởi tạo đối tượng UserInfor
			Accessory accessory = new Accessory();
			// Khởi tạo đối tượng UserValidate
			AccessoryValidate accessoryValidate = new AccessoryValidate();
			// Gọi method getDefaultValue trả về 1 UserInfor
			accessory = getDefaultValue(request);
//			// Gọi mehod validateUserInfor lấy thông báo lỗi
			listErrorMess = accessoryValidate.validateAccessory(accessory);
			// Nếu list có thông báo lỗi
			if (listErrorMess.size() > 0) {
				// Set lại giá trị default cho các select box
				setDataLogic(request);
				// set lên request
				request.setAttribute("accessory", accessory);
				// Set lỗi lên request
				request.setAttribute(Constants.LIST_ERROR_MESS, listErrorMess);
				// Forward đến trang ADM003 có lỗi
				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_ACCESSORY_JSP);
				dispatcher.forward(request, response);
			} else {
			// Khởi tạo các đối tượng
			ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
			// Lấy department theo id
			String providerName = providerLogicImpl.getProviderNameById(accessory.getProviderId());
			// Set 2 giá trị vừa lấy cho userInfor để giữ lại được khi sang MH ADM004
			accessory.setProviderName(providerName);
			// Lấy key động truyền vào tên attribute
			String dynamicKey = Common.getSalt();
			// Khởi tạo session
			HttpSession session = request.getSession();
			session.setAttribute("accessory" + dynamicKey, accessory);
			// Ghi userInfor lên session
			// để hiển thị ADM004 và giữ lại được giá trị khi click back từ ADM004
			// Đánh dấu giá trị mock khi đi qua màn hình ADM003
			session.setAttribute(Constants.FLAG, Constants.FLAG);
			// redirect đến AddUserConfirmController
			response.sendRedirect(request.getContextPath() + Constants.ADD_ACCESSORY_CONFIRM_URL + "?"
					+ Constants.DYNAMIC_KEY + "=" + dynamicKey);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Ghi log
//			System.out.println(this.getClass().getName() + " "
//					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
//			// Redirect đến controller điều khiển màn hình lỗi hệ thống
//			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * Get giá trị default cho màn hình ADM003
	 * 
	 * @param request
	 * @return UserInfor
	 */
	private Accessory getDefaultValue(HttpServletRequest request) {
		// Khởi tạo session
		HttpSession session = request.getSession();
		// Khởi tạo đối tượng UserInfor
		Accessory accessory = new Accessory();
		// Lấy action
		String typeAction = request.getParameter(Constants.ACTION);
		// Trường hợp khi click vào button xác nhận
		if (Constants.CONFIRM_ACTION.equals(typeAction)) {
			// Lấy dữ liệu từ request
			String accessoryName = request.getParameter("accessoryName");
			int providerId = Integer.parseInt(request.getParameter("providerId"));
			int number = Integer.parseInt(request.getParameter("number"));
			int status = 0;
			String size = request.getParameter("size");
			String importDate = request.getParameter("importDate");
			// Set các giá trị cho userInfor
			accessory.setAccessoryName(accessoryName);
			accessory.setProviderId(providerId);
			accessory.setStatus(status);
			accessory.setNumber(number);
			accessory.setSize(size);
			accessory.setImportDate(importDate);
		} else if (Constants.BACK_ACTION.equals(typeAction)) {
			// Lấy userInfor từ session
			accessory = (Accessory) session.getAttribute("accessory" + request.getParameter(Constants.DYNAMIC_KEY));
		} else {
			// Trường hợp default khi init MH
			accessory.setAccessoryName(Constants.BLANK);
			accessory.setProviderId(Constants.DEFAULT_VALUE);
			accessory.setStatus(Constants.DEFAULT_VALUE);
			accessory.setNumber(Constants.DEFAULT_VALUE);
			accessory.setSize(Constants.BLANK);
			accessory.setImportDate(Constants.BLANK);
		}
		// Trả về userInfor
		return accessory;
	}

	public void setDataLogic(HttpServletRequest request) throws ClassNotFoundException, SQLException {
		Common.setDataLogic(request);
		// Khởi tạo các đối tượng
		ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
		List<Provider> listProviders = new ArrayList<>();
		// Lấy danh sách
		listProviders = providerLogicImpl.getAllProviders();
		// Set các giá trị vừa lấy lên request để hiển thị
		request.setAttribute("listProviders", listProviders);
	}
}
