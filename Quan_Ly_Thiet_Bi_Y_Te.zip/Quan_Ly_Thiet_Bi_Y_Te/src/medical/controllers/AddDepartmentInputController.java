/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * AddUserController.java, Aug 10, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Department;
import medical.utils.Common;
import medical.utils.Constants;
import medical.validates.DepartmentValidate;

/**
 * 
 * Controller để xử lý cho màn hình ADM003 trường hợp add
 *
 * @author namlh
 *
 */
public class AddDepartmentInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo đối tượng UserInfor
			Department department = new Department();
			// Lấy department
			department = getDefaultValue(request);
			// set userInfor vừa lấy được lên request
			request.setAttribute("department", department);
			// Forward đến trang ADM003
			RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_DEPARTMENT_JSP);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 *
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo list chứa các câu thông báo lỗi validate
			List<String> listErrorMess = new ArrayList<>();
			// Khởi tạo đối tượng UserInfor
			Department department = new Department();
			// Khởi tạo đối tượng UserValidate
			DepartmentValidate departmentValidate = new DepartmentValidate();
			// Gọi method getDefaultValue trả về 1 UserInfor
			department = getDefaultValue(request);
			// Gọi mehod validateUserInfor lấy thông báo lỗi
			listErrorMess = departmentValidate.validateDepartment(department);
			// Nếu list có thông báo lỗi
			if (listErrorMess.size() > 0) {
				// set lên request
				request.setAttribute("department", department);
				// Set lỗi lên request
				request.setAttribute(Constants.LIST_ERROR_MESS, listErrorMess);
				// Forward đến trang ADM003 có lỗi
				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_DEPARTMENT_JSP);
				dispatcher.forward(request, response);
			} else {
				// Lấy key động truyền vào tên attribute
				String dynamicKey = Common.getSalt();
				// Khởi tạo session
				HttpSession session = request.getSession();
				// Ghi userInfor lên session
				// để hiển thị ADM004 và giữ lại được giá trị khi click back từ ADM004
				session.setAttribute("department" + dynamicKey, department);
				// Đánh dấu giá trị mock khi đi qua màn hình ADM003
				session.setAttribute(Constants.FLAG, Constants.FLAG);
				// redirect đến AddUserConfirmController
				response.sendRedirect(request.getContextPath() + Constants.ADD_DEPARTMENT_CONFIRM_URL + "?"
						+ Constants.DYNAMIC_KEY + "=" + dynamicKey);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * Get giá trị default cho màn hình ADM003
	 * 
	 * @param request
	 * @return UserInfor
	 */
	private Department getDefaultValue(HttpServletRequest request) {
		// Khởi tạo session
		HttpSession session = request.getSession();
		// Khởi tạo đối tượng UserInfor
		Department department = new Department();
		// Lấy action
		String typeAction = request.getParameter(Constants.ACTION);
		// Trường hợp khi click vào button xác nhận
		if (Constants.CONFIRM_ACTION.equals(typeAction)) {
			// Lấy dữ liệu từ request
			String departmentName = request.getParameter("departmentName");
			String address = request.getParameter("address");
			// Set các giá trị cho department
			department.setDepartmentName(departmentName);
			department.setAddress(address);
		} else if (Constants.BACK_ACTION.equals(typeAction)) {
			// Lấy userInfor từ session
			department = (Department) session.getAttribute("department" + request.getParameter(Constants.DYNAMIC_KEY));
		} else {
			// Trường hợp default khi init MH
			department.setDepartmentName(Constants.BLANK);
			department.setAddress(Constants.BLANK);
		}
		// Trả về userInfor
		return department;
	}
}
