/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * AddUserConfirmController.java, Aug 19, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Device;
import medical.logics.DeviceLogicImpl;
import medical.utils.Constants;

/**
 * 
 * Controller để xử lý cho màn hình ADM004
 *
 * @author namlh
 *
 */
public class AddDeviceConfirmController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Lấy session
			HttpSession session = request.getSession();
			// Lấy dynamicKey từ request
			String dynamicKey = request.getParameter(Constants.DYNAMIC_KEY);
			// Lấy userInfor theo dynamicKey từ session
			Device device = (Device) session.getAttribute("device" + dynamicKey);
			// Lấy giá trị flag trên session
			String flag = (String) session.getAttribute(Constants.FLAG);
			// Set các giá trị lên request
			request.setAttribute(Constants.DYNAMIC_KEY, dynamicKey);
			request.setAttribute("device", device);
			// Nếu truy cập ADM004 mà qua ADM003
			if (flag != null) {
				// Xóa flag đã lưu khi qua màn ADM003 trên session
				session.removeAttribute(Constants.FLAG);
				// Forward đến màn hình ADM004
				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.CONFIRM_DATA_DEVICE_JSP);
				dispatcher.forward(request, response);
			} else {
				// Redirect đến controller điều khiển màn hình lỗi hệ thống
				response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// url redirect
			String path = Constants.SYSTEM_ERROR_DO;
			// Lấy session
			HttpSession session = request.getSession();
			// Khởi tạo các đối tượng
			DeviceLogicImpl deviceLogicImpl = new DeviceLogicImpl();
			Device device = new Device();
			// Lấy dynamicKey từ request
			String dynamicKey = request.getParameter(Constants.DYNAMIC_KEY);
			// Lấy userInfor theo dynamicKey từ session
			device = (Device) session.getAttribute("device" + dynamicKey);
			// Lấy xong đối tượng UserInfor thì xóa đi trên session
			session.removeAttribute("device" + dynamicKey);
			// Thực hiện thêm mới user
			boolean create = deviceLogicImpl.createDevice(device);
			// Nếu thêm mới user thành công
			if (create) {
				// Lấy đường dẫn đến SuccessController với câu thông báo thêm thành công
				path = Constants.SUCCESS_URL + "?" + Constants.MESS + "=" + "MSG001_DEVICE";
			} else {
				// Nếu thêm mới user thất bại
				// Lấy đường dẫn đến SystemErrorController
				path = Constants.SYSTEM_ERROR_DO;
			}
			// Redirect đến url trong mỗi trường hợp
			response.sendRedirect(request.getContextPath() + path);
		} catch (Exception e) {
			e.printStackTrace();
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}
}
