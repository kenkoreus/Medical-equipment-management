/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * AddUserController.java, Aug 10, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Department;
import medical.entities.Device;
import medical.entities.DeviceType;
import medical.entities.Provider;
import medical.logics.DepartmentLogicImpl;
import medical.logics.DeviceTypeLogicImpl;
import medical.logics.ProviderLogicImpl;
import medical.utils.Common;
import medical.utils.Constants;

/**
 * 
 * Controller để xử lý cho màn hình ADM003 trường hợp add
 *
 * @author namlh
 *
 */
public class AddDeviceInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo đối tượng UserInfor
			Device device = new Device();
			// Set giá trị cho các hạng mục selectbox ở màn hình ADM003
			setDataLogic(request);
			// Lấy userInfor
			device = getDefaultValue(request);
			// set userInfor vừa lấy được lên request
			request.setAttribute("device", device);
			// Forward đến trang ADM003
			RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_DEVICE_JSP);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 *
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo list chứa các câu thông báo lỗi validate
//			List<String> listErrorMess = new ArrayList<>();
			// Khởi tạo đối tượng UserInfor
			Device device = new Device();
			// Khởi tạo đối tượng UserValidate
//			DeviceValidate deviceValidate = new DeviceValidate();
			// Gọi method getDefaultValue trả về 1 UserInfor
			device = getDefaultValue(request);
//			// Gọi mehod validateUserInfor lấy thông báo lỗi
//			listErrorMess = deviceValidate.validateDevice(device);
			// Nếu list có thông báo lỗi
//			if (listErrorMess.size() > 0) {
//				// Set lại giá trị default cho các select box
//				Common.setDataLogic(request);
//				// set lên request
//				request.setAttribute("user", device);
//				// Set lỗi lên request
//				request.setAttribute(Constants.LIST_ERROR_MESS, listErrorMess);
//				// Forward đến trang ADM003 có lỗi
//				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_USER_JSP);
//				dispatcher.forward(request, response);
//			} else {
			// Khởi tạo các đối tượng
			DepartmentLogicImpl departmentLogicImpl = new DepartmentLogicImpl();
			DeviceTypeLogicImpl deviceTypeLogicImpl = new DeviceTypeLogicImpl();
			ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
			// Lấy department theo id
			String departmentName = departmentLogicImpl.getDepartmentNameById(device.getDepartmentId());
			String deviceTypeName = deviceTypeLogicImpl.getDeviceTypeNameById(device.getDeviceTypeId());
			String providerName = providerLogicImpl.getProviderNameById(device.getProviderId());
			// Set 2 giá trị vừa lấy cho userInfor để giữ lại được khi sang MH ADM004
			device.setDepartmentName(departmentName);
			device.setDeviceTypeName(deviceTypeName);
			device.setProviderName(providerName);
			// Lấy key động truyền vào tên attribute
			String dynamicKey = Common.getSalt();
			// Khởi tạo session
			HttpSession session = request.getSession();
			System.out.println("dynamicKey1"+dynamicKey);
			session.setAttribute("device" + dynamicKey, device);
			// Ghi userInfor lên session
			// để hiển thị ADM004 và giữ lại được giá trị khi click back từ ADM004
			// Đánh dấu giá trị mock khi đi qua màn hình ADM003
			session.setAttribute(Constants.FLAG, Constants.FLAG);
			// redirect đến AddUserConfirmController
			response.sendRedirect(request.getContextPath() + Constants.ADD_DEVICE_CONFIRM_URL + "?"
					+ Constants.DYNAMIC_KEY + "=" + dynamicKey);
//			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển màn hình lỗi hệ thống
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * Get giá trị default cho màn hình ADM003
	 * 
	 * @param request
	 * @return UserInfor
	 */
	private Device getDefaultValue(HttpServletRequest request) {
		// Khởi tạo session
		HttpSession session = request.getSession();
		// Khởi tạo đối tượng UserInfor
		Device device = new Device();
		// Lấy action
		String typeAction = request.getParameter(Constants.ACTION);
		// Trường hợp khi click vào button xác nhận
		if (Constants.CONFIRM_ACTION.equals(typeAction)) {
			// Lấy dữ liệu từ request
			String deviceName = request.getParameter("deviceName");
			String deviceModel = request.getParameter("deviceModel");
			String deviceSerial = request.getParameter("deviceSerial");
			int departmentId = Integer.parseInt(request.getParameter("departmentId"));
			int deviceTypeId = Integer.parseInt(request.getParameter("deviceTypeId"));
			int providerId = Integer.parseInt(request.getParameter("providerId"));
			String country = request.getParameter("country");
			String manufacture = request.getParameter("manufacture");
			String productDate = request.getParameter("productDate");
			String importDate = request.getParameter("importDate");
			String handoverDate = request.getParameter("handoverDate");
			int statusId = 1;
			String expireDate = request.getParameter("expireDate");
			String price = request.getParameter("price");
			String note = request.getParameter("note");
			// Set các giá trị cho userInfor
			device.setDeviceName(deviceName);
			device.setDeviceModel(deviceModel);
			device.setDeviceSerial(deviceSerial);
			device.setDeviceTypeId(deviceTypeId);
			device.setProviderId(providerId);
			device.setDepartmentId(departmentId);
			device.setCountry(country);
			device.setManufacture(manufacture);
			device.setProductDate(productDate);
			device.setImportDate(importDate);
			device.setHandoverDate(handoverDate);
			device.setStatusId(statusId);
			device.setExpireDate(expireDate);
			device.setPrice(price);
			device.setNote(note);
		} else if (Constants.BACK_ACTION.equals(typeAction)) {
			// Lấy userInfor từ session
			device = (Device) session.getAttribute("device" + request.getParameter(Constants.DYNAMIC_KEY));
		} else {
			// Trường hợp default khi init MH
			device.setDeviceName(Constants.BLANK);
			device.setDeviceModel(Constants.BLANK);
			device.setDeviceSerial(Constants.BLANK);
			device.setDeviceTypeId(Constants.DEFAULT_VALUE);
			device.setProviderId(Constants.DEFAULT_VALUE);
			device.setDepartmentId(Constants.DEFAULT_VALUE);
			device.setCountry(Constants.BLANK);
			device.setManufacture(Constants.BLANK);
			device.setProductDate(Constants.BLANK);
			device.setImportDate(Constants.BLANK);
			device.setHandoverDate(Constants.BLANK);
			device.setStatus(Constants.BLANK);
			device.setExpireDate(Constants.BLANK);
			device.setPrice(Constants.BLANK);
			device.setNote(Constants.BLANK);
		}
		// Trả về userInfor
		return device;
	}

	public void setDataLogic(HttpServletRequest request) throws ClassNotFoundException, SQLException {
		Common.setDataLogic(request);
		// Khởi tạo các đối tượng
		DepartmentLogicImpl departmentLogicImpl = new DepartmentLogicImpl();
		ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
		DeviceTypeLogicImpl deviceTypeLogicImpl = new DeviceTypeLogicImpl();
		List<Department> listDepartments = new ArrayList<>();
		List<Provider> listProviders = new ArrayList<>();
		List<DeviceType> listDeviceTypes = new ArrayList<>();
		// Lấy danh sách
		listDepartments = departmentLogicImpl.getAllDepartments();
		listProviders = providerLogicImpl.getAllProviders();
		listDeviceTypes = deviceTypeLogicImpl.getAllDeviceTypes();
		// Set các giá trị vừa lấy lên request để hiển thị
		request.setAttribute("listDepartments", listDepartments);
		request.setAttribute("listProviders", listProviders);
		request.setAttribute("listDeviceTypes", listDeviceTypes);
	}
}
