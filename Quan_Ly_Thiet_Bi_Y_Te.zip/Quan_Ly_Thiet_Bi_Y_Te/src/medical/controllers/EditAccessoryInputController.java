/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * EditAccessoryInputController.java, Aug 10, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Accessory;
import medical.entities.Department;
import medical.entities.Provider;
import medical.logics.AccessoryLogicImpl;
import medical.logics.DepartmentLogicImpl;
import medical.logics.ProviderLogicImpl;
import medical.utils.Common;
import medical.utils.Constants;
import medical.validates.AccessoryValidate;

/**
 * 
 * Controller để xử lý cho màn hình ADM003 trường hợp edit
 *
 * @author namlh
 *
 */
public class EditAccessoryInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo các đối tượng
			AccessoryLogicImpl accessoryLogicImpl = new AccessoryLogicImpl();
			Accessory accessory = null;
			// Lấy accessoryId từ request
			String accessoryIdFromRequest = request.getParameter("accessoryId");
			// Parse accessoryId sang Integer
			int accessoryId = Common.convertStringToInteger(accessoryIdFromRequest, Constants.DEFAULT_VALUE);
			// Nếu Parse accessoryId thành công và accessory đó có tồn tại trong DB
			if (accessoryId > Constants.DEFAULT_VALUE && accessoryLogicImpl.checkExistAccessory(accessoryId)) {
				// Lấy về AccessoryInfor từ method getDefaultValue
				accessory = getDefaultValue(request);
			}
			
			// Nếu accessoryInfor khác null
			if (accessory != null) {
				// Set lại giá trị cho các pulldown ở màn hình ADM003
				ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
				List<Provider> listProviders = new ArrayList<>();
				listProviders = providerLogicImpl.getAllProviders();
				request.setAttribute("listProviders", listProviders);
				// Set accessoryInfor lên request
				request.setAttribute("accessory", accessory);
				// Set action là edit lên request để hiển thị ADM003 trường hợp edit
				request.setAttribute(Constants.ACTION, Constants.EDIT_ACTION);
				// Forward đến MH ADM003
				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_ACCESSORY_JSP);
				dispatcher.forward(request, response);
			} else {
				// Redirect đến controller điều khiển lỗi với câu thông báo accessory không tồn tại
				response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO + "?" + Constants.MESS + "="
						+ Constants.USER_NOT_EXIST);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển lỗi
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Danh sách chứa các câu thông báo lỗi validate
			List<String> listErrorMess = new ArrayList<>();
			// Khởi tạo các đối tượng
			AccessoryLogicImpl accessoryLogicImpl = new AccessoryLogicImpl();
			AccessoryValidate accessoryValidate = new AccessoryValidate();
			Accessory accessory = null;
			// Lấy về accessoryId từ request, parse sang int
			int accessoryId = Common.convertStringToInteger(request.getParameter("accessoryId"),
					Constants.DEFAULT_VALUE);
			// Nếu parse accessoryId thành công và accessory đó có tồn tại trong DB
			if (accessoryId > 0 && accessoryLogicImpl.checkExistAccessory(accessoryId)) {
				// Gọi method getDefaultValue trả về 1 AccessoryInfor
				accessory = getDefaultValue(request);
				// Gọi mehod validateAccessoryInfor lấy thông báo lỗi
				listErrorMess = accessoryValidate.validateAccessory(accessory);
				// Nếu list có thông báo lỗi
				if (listErrorMess.size() > 0) {
					// Set action là edit lên request để hiển thị ADM003 trường hợp edit
					request.setAttribute(Constants.ACTION, Constants.EDIT_ACTION);
					// Set lại giá trị default cho các select box
					ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
					List<Provider> listProviders = new ArrayList<>();
					listProviders = providerLogicImpl.getAllProviders();
					request.setAttribute("listProviders", listProviders);
					// set accessoryInfor lên request
					request.setAttribute("accessory", accessory);
					// Set danh sách lỗi lên request
					request.setAttribute(Constants.LIST_ERROR_MESS, listErrorMess);
					// Forward đến trang ADM003
					RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_ACCESSORY_JSP);
					dispatcher.forward(request, response);
				} else {
					// Nếu không có lỗi
					// Khởi tạo các đối tượng
					ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
					// Lấy groupName theo groupId
					String providerName = providerLogicImpl.getProviderNameById(accessory.getProviderId());
					// Set 2 giá trị vừa lấy cho accessoryInfor để giữ lại được khi sang MH ADM004
					accessory.setProviderName(providerName);
					// Lấy session
					HttpSession session = request.getSession();
					// Lấy key động
					String dynamicKey = Common.getSalt();
					// Ghi accessoryInfor lên session theo key động
					// để giữ lại được giá trị khi click back từ ADM004
					session.setAttribute("accessory" + dynamicKey, accessory);
					// Đánh dấu cờ khi đi qua màn hình ADM003
					session.setAttribute(Constants.FLAG, Constants.FLAG);
					// redirect đến EditAccessoryConfirmController
					response.sendRedirect(request.getContextPath() + Constants.EDIT_ACCESSORY_CONFIRM_URL + "?"
							+ Constants.DYNAMIC_KEY + "=" + dynamicKey);
				}
			} else {
				// Redirect đến controller điều khiển lỗi với câu thông báo accessory không tồn tại
				response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO + "?" + Constants.MESS + "="
						+ Constants.USER_NOT_EXIST);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển lỗi
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * Get giá trị default cho màn hình ADM003 TH edit
	 * 
	 * @param request
	 * @return AccessoryInfor
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	private Accessory getDefaultValue(HttpServletRequest request) throws ClassNotFoundException, SQLException {
		// Khởi tạo các đối tượng
		Accessory accessory = null;
		// Lấy action
		String typeAction = request.getParameter(Constants.ACTION);
		// Lấy accessoryId từ request
		int accessoryId = Common.convertStringToInteger(request.getParameter("accessoryId"), Constants.DEFAULT_VALUE);
		// Trường hợp khi click vào button xác nhận
		if (Constants.CONFIRM_ACTION.equals(typeAction)) {
			accessory = new Accessory();
			// Lấy dữ liệu từ request set cho accessoryInfor
			String accessoryName = request.getParameter("accessoryName");
			int providerId = Integer.parseInt(request.getParameter("providerId"));
			int number = Integer.parseInt(request.getParameter("number"));
			int status = Integer.parseInt(request.getParameter("status"));
			String size = request.getParameter("size");
			String importDate = request.getParameter("importDate");
			// Set các giá trị cho userInfor
			accessory.setAccessoryId(accessoryId);
			accessory.setAccessoryName(accessoryName);
			accessory.setProviderId(providerId);
			accessory.setStatus(status);
			accessory.setNumber(number);
			accessory.setSize(size);
			accessory.setImportDate(importDate);
		} else if (Constants.BACK_ACTION.equals(typeAction)) { // Trường hợp back từ ADM004
			// Khởi tạo session
			HttpSession session = request.getSession();
			// Lấy accessoryInfor từ session
			accessory = (Accessory) session.getAttribute("accessory" + request.getParameter(Constants.DYNAMIC_KEY));
		} else { // Trường hợp từ ADM005 sang ADM003
			AccessoryLogicImpl accessoryLogicImpl = new AccessoryLogicImpl();
			// Nếu accessory đó có tồn tại trong DB thì gọi method getAccessoryById lấy về 1 accessoryInfor
			accessory = accessoryLogicImpl.getAccessoryById(accessoryId);
		}
		// Trả về accessoryInfor
		return accessory;
	}
}
