/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * EditUserInputController.java, Aug 10, 2019, namlh 
 */
package medical.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import medical.entities.Provider;
import medical.logics.ProviderLogicImpl;
import medical.utils.Common;
import medical.utils.Constants;
import medical.validates.ProviderValidate;

/**
 * 
 * Controller để xử lý cho màn hình ADM003 trường hợp edit
 *
 * @author namlh
 *
 */
public class EditProviderInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Khởi tạo các đối tượng
			ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
			Provider provider = null;
			// Lấy userId từ request
			String providerIdFromRequest = request.getParameter("providerId");
			// Parse userId sang Integer
			int providerId = Common.convertStringToInteger(providerIdFromRequest, Constants.DEFAULT_VALUE);
			// Nếu Parse userId thành công và user đó có tồn tại trong DB
			if (providerId > Constants.DEFAULT_VALUE && providerLogicImpl.checkExistProvider(providerId)) {
				// Lấy về UserInfor từ method getDefaultValue
				provider = getDefaultValue(request);
			}

			// Nếu userInfor khác null
			if (provider != null) {
				// Set userInfor lên request
				request.setAttribute("provider", provider);
				// Set action là edit lên request để hiển thị ADM003 trường hợp edit
				request.setAttribute(Constants.ACTION, Constants.EDIT_ACTION);
				// Forward đến MH ADM003
				RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_PROVIDER_JSP);
				dispatcher.forward(request, response);
			} else {
				// Redirect đến controller điều khiển lỗi với câu thông báo user không tồn tại
				response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO + "?" + Constants.MESS + "="
						+ Constants.USER_NOT_EXIST);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển lỗi
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Danh sách chứa các câu thông báo lỗi validate
			List<String> listErrorMess = new ArrayList<>();
			// Khởi tạo các đối tượng
			ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
			ProviderValidate providerValidate = new ProviderValidate();
			Provider provider = null;
			// Lấy về userId từ request, parse sang int
			int providerId = Common.convertStringToInteger(request.getParameter("providerId"),
					Constants.DEFAULT_VALUE);
			// Nếu parse userId thành công và user đó có tồn tại trong DB
			System.out.println(providerId	);
			if (providerId > 0 && providerLogicImpl.checkExistProvider(providerId)) {
				// Gọi method getDefaultValue trả về 1 UserInfor
				provider = getDefaultValue(request);
				// Gọi mehod validateUserInfor lấy thông báo lỗi
				listErrorMess = providerValidate.validateProvider(provider);
				// Nếu list có thông báo lỗi
				if (listErrorMess.size() > 0) {
					// Set action là edit lên request để hiển thị ADM003 trường hợp edit
					request.setAttribute(Constants.ACTION, Constants.EDIT_ACTION);
					// set userInfor lên request
					request.setAttribute("provider", provider);
					// Set danh sách lỗi lên request
					request.setAttribute(Constants.LIST_ERROR_MESS, listErrorMess);
					// Forward đến trang ADM003
					RequestDispatcher dispatcher = request.getRequestDispatcher(Constants.ADD_PROVIDER_JSP);
					dispatcher.forward(request, response);
				} else {
					// Đường dẫn redirect
					String path = Constants.SYSTEM_ERROR_DO;
					// Nếu user có tồn tại trong DB
					if (providerLogicImpl.checkExistProvider(providerId)) {
						// Gọi method updateUser() và kiểm tra
						if (providerLogicImpl.updateProvider(provider)) {
							// Nếu update user thành công thì lấy đường dẫn chứa câu update thành công
							path = Constants.SUCCESS_URL + "?" + Constants.MESS + "=" + "MSG002_PROVIDER";
						} else {
							// Nếu update user thất bại thì lấy đường dẫn chứa câu lỗi hệ thống
							path = Constants.SYSTEM_ERROR_DO;
						}
					} else {
						// Nếu đã bị trùng email khác trong DB thì lấy đường dẫn chứa câu user không tồn
						// tại
						path = Constants.SYSTEM_ERROR_DO + "?" + Constants.MESS + "=" + Constants.USER_NOT_EXIST;
					}
					// Redirect đến controller điều khiển trong từng trường hợp
					response.sendRedirect(request.getContextPath() + path);
				}
			} else {
				// Redirect đến controller điều khiển lỗi với câu thông báo user không tồn tại
				response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO + "?" + Constants.MESS + "="
						+ Constants.USER_NOT_EXIST);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// Redirect đến controller điều khiển lỗi
			response.sendRedirect(request.getContextPath() + Constants.SYSTEM_ERROR_DO);
		}
	}

	/**
	 * Get giá trị default cho màn hình ADM003 TH edit
	 * 
	 * @param request
	 * @return UserInfor
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	private Provider getDefaultValue(HttpServletRequest request) throws ClassNotFoundException, SQLException {
		// Khởi tạo các đối tượng
		Provider provider = null;
		ProviderLogicImpl providerLogicImpl = new ProviderLogicImpl();
		// Lấy action
		String typeAction = request.getParameter(Constants.ACTION);
		// Lấy userId từ request
		int providerId = Common.convertStringToInteger(request.getParameter("providerId"), Constants.DEFAULT_VALUE);
		// Trường hợp khi click vào button xác nhận
		if (Constants.CONFIRM_ACTION.equals(typeAction)) {
			provider = new Provider();
			// Lấy dữ liệu từ request set cho userInfor
			provider.setProviderId(providerId);
			provider.setProviderName(request.getParameter("providerName"));
			provider.setAddress(request.getParameter("address"));
			provider.setMobile(request.getParameter("mobile"));
			provider.setEmail(request.getParameter("email"));
		} else if (Constants.BACK_ACTION.equals(typeAction)) { // Trường hợp back từ ADM004
			// Khởi tạo session
			HttpSession session = request.getSession();
			// Lấy userInfor từ session
			provider = (Provider) session.getAttribute("provider" + request.getParameter(Constants.DYNAMIC_KEY));
		} else {
			provider = new Provider();
			provider = providerLogicImpl.getProviderById(providerId);
		}
		// Trả về userInfor
		return provider;
	}
}
