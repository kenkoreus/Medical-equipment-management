/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * TblUserDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Accessory;
import medical.entities.Device;
import medical.entities.User;
import medical.utils.Common;
import medical.utils.Constants;

/**
 * Implement UserDao, thao tác với cơ sở dữ liệu liên quan đến bảng tbl_user
 *
 * @author namlh
 *
 */
public class AccessoryDaoImpl extends BaseDaoImpl {

	public User getUserByLoginName(String loginName) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, role ");
				sqlCommand.append("FROM user WHERE login_name = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, loginName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setRole(rs.getInt("role"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public User getUserByLoginName(String loginName, int rule) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, password, salt FROM user ");
				sqlCommand.append("WHERE login_name = BINARY ? AND role = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setString(++index, loginName);
				ps.setInt(++index, rule);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setPassword(rs.getString("password"));
					user.setSalt(rs.getString("salt"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public int getTotalAccessories(int providerId, String accessoryName) throws SQLException, ClassNotFoundException {
		int totalRecords = 0;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT COUNT(acc_id) AS total_accessory FROM accessory a ");
				sqlCommand.append("INNER JOIN provider p ON a.provider_id = p.provider_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(accessoryName)) {
					sqlCommand.append("AND a.acc_name like ? ");
				}
				// Nếu có chọn groupId
				if (providerId != 0) {
					sqlCommand.append("AND a.provider_id = ? ");
				}

				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				if (!accessoryName.isEmpty()) {
					ps.setString(++index, "%" + accessoryName + "%");
				}

				if (providerId != 0) {
					ps.setInt(++index, providerId);
				}

				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					totalRecords = rs.getInt("total_accessory");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return totalRecords;
	}

	public List<Accessory> getListDevices(int offset, int limit, int providerId, String accessoryName,
			String sortByDeviceName) throws SQLException, ClassNotFoundException {
		List<Accessory> listAccessories = new ArrayList<>();
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"SELECT a.acc_id, a.acc_name, a.provider_id, p.provider_name, a.size, a.number, a.import_date, a.status ");
				sqlCommand.append("FROM accessory a ");
				sqlCommand.append("INNER JOIN provider p ON a.provider_id = p.provider_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(accessoryName)) {
					sqlCommand.append("AND a.acc_name like ? ");
				}
				// Nếu có chọn groupId
				if (providerId != 0) {
					sqlCommand.append("AND a.provider_id = ? ");
				}

				sqlCommand.append("LIMIT ? OFFSET ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				if (!accessoryName.isEmpty()) {
					ps.setString(++index, "%" + accessoryName + "%");
				}

				if (providerId != 0) {
					ps.setInt(++index, providerId);
				}
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					Accessory accessory = new Accessory();
					accessory.setAccessoryId(rs.getInt("acc_id"));
					accessory.setAccessoryName(rs.getString("acc_name"));
					accessory.setProviderId(rs.getInt("provider_id"));
					accessory.setProviderName(rs.getString("provider_name"));
					accessory.setNumber(rs.getInt("number"));
					accessory.setSize(rs.getString("size"));
					accessory.setStatus(rs.getInt("status"));
					accessory.setImportDate(rs.getString("import_date"));
					listAccessories.add(accessory);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return listAccessories;
	}

	public Accessory getAccessoryById(int accessoryId) throws SQLException, ClassNotFoundException {
		Accessory accessory = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"SELECT a.acc_id, a.acc_name, a.provider_id, a.size, a.number, a.import_date, a.status ");
				sqlCommand.append("FROM accessory a ");
				sqlCommand.append("INNER JOIN provider p ON a.provider_id = p.provider_id ");
				sqlCommand.append("WHERE a.acc_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, accessoryId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					accessory = new Accessory();
					// Set các giá trị từ đối tượng ResultSet cho UserInfor
					accessory.setAccessoryId(rs.getInt("acc_id"));
					accessory.setAccessoryName(rs.getString("acc_name"));
					accessory.setProviderId(rs.getInt("provider_id"));
					accessory.setSize(rs.getString("size"));
					accessory.setNumber(rs.getInt("number"));
					accessory.setImportDate(rs.getString("import_date"));
					accessory.setStatus(rs.getInt("status"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return accessory;
	}

	public User getUserByEmail(String email) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT user_id, email ");
				sqlCommand.append("FROM user WHERE email = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, email);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setUserId(rs.getInt("user_id"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public boolean checkExistAccessoryById(int accessoryId) throws SQLException, ClassNotFoundException {
		boolean exist = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT acc_id FROM accessory ");
				sqlCommand.append("WHERE acc_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, accessoryId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					exist = true;
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return exist;
	}

	public boolean insertAccessory(Accessory accessory) throws SQLException, ClassNotFoundException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("INSERT INTO accessory(acc_name, provider_id, size, number, import_date, status) ");
				sqlCommand.append("VALUES (?, ?, ?, ?, ?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, accessory.getAccessoryName());
				ps.setInt(++index, accessory.getProviderId());
				ps.setString(++index, accessory.getSize());
				ps.setInt(++index, accessory.getNumber());
				ps.setString(++index, accessory.getImportDate());
				ps.setInt(++index, accessory.getStatus());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			insert = false;
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	public void updateAccessory(Accessory accessory) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"UPDATE accessory SET acc_name = ?, provider_id = ?, size = ?, number = ?, import_date = ?, status = ? ");
				sqlCommand.append("WHERE acc_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, accessory.getAccessoryName());
				ps.setInt(++index, accessory.getProviderId());
				ps.setString(++index, accessory.getSize());
				ps.setInt(++index, accessory.getNumber());
				ps.setString(++index, accessory.getImportDate());
				ps.setInt(++index, accessory.getStatus());
				ps.setInt(++index, accessory.getAccessoryId());
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	public void deleteAccessory(int accessoryId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM accessory ");
				sqlCommand.append("WHERE acc_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, accessoryId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	/**
	 * Lấy câu query OrderBy
	 * 
	 * @param String sortType - column được ưu tiên sort trước
	 * @param String sortByFullName - kiểu sort của fullName
	 * @param String sortByCodeLevel - kiểu sort của fullName
	 * @param String sortByEndDate - kiểu sort của fullName
	 * @return String - câu query OrderBy
	 */

	public String getQueryOrderBy(String sortType, String sortByFullName, String sortByCodeLevel,
			String sortByEndDate) {
		// Chuỗi StringBuilder chứa câu truy vấn
		StringBuilder sqlCommand = new StringBuilder();
		// Chia điều kiện sort ưu tiên
		switch (sortType) {
		// ưu tiên theo full_name
		case Constants.FULLNAME:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo code_level
		case Constants.CODE_LEVEL:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo end_date
		case Constants.END_DATE:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("dj.end_date " + sortByEndDate);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			break;
		}
		// Trả về câu query dạng String
		return sqlCommand.toString();
	}
}
