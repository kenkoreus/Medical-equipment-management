/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Department;
import medical.entities.User;
import medical.utils.Constants;

/**
 * [Implement MstGroupDao để Xử lý Thao tác với DB bảng mst_group ]
 *
 * @author namlh
 *
 */
public class DepartmentDaoImpl extends BaseDaoImpl {

	public int getTotalDepartments() throws SQLException, ClassNotFoundException {
		int totalRecords = 0;
		try {
			if (connectDB()) {
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT COUNT(department_id) AS total_department FROM department ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					totalRecords = rs.getInt("total_department");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return totalRecords;
	}

	public List<Department> getAllDepartments(int limit, int offset) throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<Department> listDepartments = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT department_id, department_name, address FROM department ");
				sqlCommand.append("LIMIT ? OFFSET ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					Department department = new Department();
					department.setDepartmentId(rs.getInt("department_id"));
					department.setDepartmentName(rs.getString("department_name"));
					department.setAddress(rs.getString("address"));
					// Add MstGroup vào listGroups
					listDepartments.add(department);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listDepartments;
	}

	public List<Department> getAllDepartments() throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<Department> listDepartments = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT department_id, department_name, address FROM department ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					Department department = new Department();
					department.setDepartmentId(rs.getInt("department_id"));
					department.setDepartmentName(rs.getString("department_name"));
					department.setAddress(rs.getString("address"));
					// Add MstGroup vào listGroups
					listDepartments.add(department);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listDepartments;
	}

	public String getDepartmentNameById(int departmentId) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		String departmentName = "";
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT department_name FROM department WHERE department_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setInt(++index, departmentId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// lấy giá trị groupName
					departmentName = rs.getString("department_name");
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return departmentName;
	}

	public boolean checkExistDepartment(String departmentName) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		boolean check = false;
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT department_name FROM department WHERE department_name = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setString(++index, departmentName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					check = true;
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return check;
	}

	public boolean insertDepartment(Department department) throws ClassNotFoundException, SQLException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("INSERT INTO department(department_name, address) ");
				sqlCommand.append("VALUES (?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, department.getDepartmentName());
				ps.setString(++index, department.getAddress());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	/**
	 * @param departmentId
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Department getDepartmentById(int departmentId) throws ClassNotFoundException, SQLException {
		Department department = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT department_name, address FROM department ");
				sqlCommand.append("WHERE department_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, departmentId);
				rs = ps.executeQuery();
				while (rs.next()) {
					department = new Department();
					department.setDepartmentId(departmentId);
					department.setDepartmentName(rs.getString("department_name"));
					department.setAddress(rs.getString("address"));
				}

			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return department;
	}

	public void updateDepartment(Department department) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("UPDATE department SET department_name = ?, address = ? ");
				sqlCommand.append("WHERE department_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, department.getDepartmentName());
				ps.setString(++index, department.getAddress());
				ps.setInt(++index, department.getDepartmentId());
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteUserWithDepartment(int departmentId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM user ");
				sqlCommand.append("WHERE department_id = ?; ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, departmentId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteDepartment(int departmentId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM department ");
				sqlCommand.append("WHERE department_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, departmentId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
}
