/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * TblUserDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Device;
import medical.entities.User;
import medical.utils.Common;
import medical.utils.Constants;

/**
 * Implement UserDao, thao tác với cơ sở dữ liệu liên quan đến bảng tbl_user
 *
 * @author namlh
 *
 */
public class DeviceDaoImpl extends BaseDaoImpl {

	public User getUserByLoginName(String loginName) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, role ");
				sqlCommand.append("FROM user WHERE login_name = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, loginName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setRole(rs.getInt("role"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public User getUserByLoginName(String loginName, int rule) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, password, salt FROM user ");
				sqlCommand.append("WHERE login_name = BINARY ? AND role = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setString(++index, loginName);
				ps.setInt(++index, rule);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setPassword(rs.getString("password"));
					user.setSalt(rs.getString("salt"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public int getTotalDevices(int departmentId, int deviceTypeId, String deviceName)
			throws SQLException, ClassNotFoundException {
		int totalRecords = 0;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT COUNT(dv_id) AS total_device FROM device dv ");
				sqlCommand.append("INNER JOIN department d ON dv.department_id = d.department_id ");
				sqlCommand.append("INNER JOIN device_type dt ON dv.dv_type_id = dt.dv_type_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(deviceName)) {
					sqlCommand.append("AND dv.dv_name like ? ");
				}
				// Nếu có chọn groupId
				if (departmentId != 0) {
					sqlCommand.append("AND d.department_id = ? ");
				}

				// Nếu có chọn groupId
				if (deviceTypeId != 0) {
					sqlCommand.append("AND dt.dv_type_id = ? ");
				}

				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				if (!deviceName.isEmpty()) {
					ps.setString(++index, "%" + deviceName + "%");
				}

				if (departmentId != 0) {
					ps.setInt(++index, departmentId);
				}
				if (deviceTypeId != 0) {
					ps.setInt(++index, deviceTypeId);
				}

				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					totalRecords = rs.getInt("total_device");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return totalRecords;
	}

	public List<Device> getListDevices(int offset, int limit, int departmentId, int deviceTypeId, String deviceName,
			String sortByDeviceName) throws SQLException, ClassNotFoundException {
		List<Device> listDevices = new ArrayList<>();
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv.dv_id, dv.dv_name, d.department_name, p.provider_name, dt.dv_type_name, s.status_id, s.status_name ");
				sqlCommand.append("FROM device dv ");
				sqlCommand.append("INNER JOIN department d ON dv.department_id = d.department_id ");
				sqlCommand.append("INNER JOIN device_type dt ON dv.dv_type_id = dt.dv_type_id ");
				sqlCommand.append("INNER JOIN provider p ON dv.provider_id = p.provider_id ");
				sqlCommand.append("INNER JOIN status_device s ON dv.status = s.status_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(deviceName)) {
					sqlCommand.append("AND dv.dv_name like ? ");
				}
				// Nếu có chọn groupId
				if (departmentId != 0) {
					sqlCommand.append("AND d.department_id = ? ");
				}

				// Nếu có chọn groupId
				if (deviceTypeId != 0) {
					sqlCommand.append("AND dt.dv_type_id = ? ");
				}
				sqlCommand.append("ORDER BY ");
				sqlCommand.append("dv.dv_name " + sortByDeviceName );
				sqlCommand.append(" LIMIT ? OFFSET ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				if (!deviceName.isEmpty()) {
					ps.setString(++index, "%" + deviceName + "%");
				}

				if (departmentId != 0) {
					ps.setInt(++index, departmentId);
				}
				if (deviceTypeId != 0) {
					ps.setInt(++index, deviceTypeId);
				}
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					Device device = new Device();
					device.setDeviceId(rs.getInt("dv_id"));
					device.setDeviceName(rs.getString("dv_name"));
					device.setDepartmentName(rs.getString("department_name"));
					device.setProviderName(rs.getString("provider_name"));
					device.setDeviceTypeName(rs.getString("dv_type_name"));
					device.setStatus(rs.getString("status_name"));
					device.setStatusId(rs.getInt("status_id"));
					listDevices.add(device);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return listDevices;
	}

	public Device getDeviceById(int deviceId) throws SQLException, ClassNotFoundException {
		Device device = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"SELECT dv.dv_id, dv.dv_name, dv.dv_model, dv.dv_serial, dv.dv_type_id, dv.provider_id, d.department_name, dt.dv_type_name, p.provider_name, ");
				sqlCommand.append(
						"dv.department_id, dv.country, dv.manufacture, dv.product_date, dv.import_date, dv. handover_date, dv.status, dv.expire_date, dv.price, dv.note ");
				sqlCommand.append("FROM device dv ");
				sqlCommand.append("INNER JOIN department d ON dv.department_id = d.department_id ");
				sqlCommand.append("INNER JOIN device_type dt ON dv.dv_type_id = dt.dv_type_id ");
				sqlCommand.append("INNER JOIN provider p ON dv.provider_id = p.provider_id ");
				sqlCommand.append("WHERE dv.dv_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					device = new Device();
					// Set các giá trị từ đối tượng ResultSet cho UserInfor
					device.setDeviceId(rs.getInt("dv_id"));
					device.setDeviceName(rs.getString("dv_name"));
					device.setDeviceModel(rs.getString("dv_model"));
					device.setDeviceSerial(rs.getString("dv_serial"));
					device.setDeviceTypeId(rs.getInt("dv_type_id"));
					device.setProviderId(rs.getInt("provider_id"));
					device.setDepartmentId(rs.getInt("department_id"));
					device.setDepartmentName(rs.getString("department_name"));
					device.setDeviceTypeName(rs.getString("dv_type_name"));
					device.setProviderName(rs.getString("provider_name"));
					device.setCountry(rs.getString("country"));
					device.setManufacture(rs.getString("manufacture"));
					device.setProductDate(rs.getString("product_date"));
					device.setImportDate(rs.getString("import_date"));
					device.setHandoverDate(rs.getString("handover_date"));
					device.setStatus(rs.getString("status"));
					device.setExpireDate(rs.getString("expire_date"));
					device.setPrice(rs.getString("price"));
					device.setNote(rs.getString("note"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return device;
	}

	public User getUserByEmail(String email) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT user_id, email ");
				sqlCommand.append("FROM user WHERE email = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, email);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setUserId(rs.getInt("user_id"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public boolean checkExistDeviceById(int deviceId) throws SQLException, ClassNotFoundException {
		boolean exist = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_id FROM device ");
				sqlCommand.append("WHERE dv_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					exist = true;
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return exist;
	}

	public boolean insertDevice(Device device) throws SQLException, ClassNotFoundException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"INSERT INTO device(dv_name, dv_model, dv_serial, dv_type_id, provider_id, department_id, country, manufacture, product_date, import_date, handover_date, status, expire_date, price, note) ");
				sqlCommand.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, device.getDeviceName());
				ps.setString(++index, device.getDeviceModel());
				ps.setString(++index, device.getDeviceSerial());
				ps.setInt(++index, device.getDeviceTypeId());
				ps.setInt(++index, device.getProviderId());
				ps.setInt(++index, device.getDepartmentId());
				ps.setString(++index, device.getCountry());
				ps.setString(++index, device.getManufacture());
				ps.setString(++index, device.getProductDate());
				ps.setString(++index, device.getImportDate());
				ps.setString(++index, device.getHandoverDate());
				ps.setInt(++index, device.getStatusId());
				ps.setString(++index, device.getExpireDate());
				ps.setString(++index, device.getPrice());
				ps.setString(++index, device.getNote());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			insert = false;
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	public void updateDevice(Device device) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"UPDATE device SET dv_name = ?, dv_model = ?, dv_serial = ?, dv_type_id = ?, provider_id = ?, department_id = ?, ");
				sqlCommand.append(
						"country = ?, manufacture = ?, product_date = ?, import_date = ?, handover_date = ?, status = ?, expire_date = ?, price = ?, note = ? ");
				sqlCommand.append("WHERE dv_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, device.getDeviceName());
				ps.setString(++index, device.getDeviceModel());
				ps.setString(++index, device.getDeviceSerial());
				ps.setInt(++index, device.getDeviceTypeId());
				ps.setInt(++index, device.getProviderId());
				ps.setInt(++index, device.getDepartmentId());
				ps.setString(++index, device.getCountry());
				ps.setString(++index, device.getManufacture());
				ps.setString(++index, device.getProductDate());
				ps.setString(++index, device.getImportDate());
				ps.setString(++index, device.getHandoverDate());
				ps.setInt(++index, device.getStatusId());
				ps.setString(++index, device.getExpireDate());
				ps.setString(++index, device.getPrice());
				ps.setString(++index, device.getNote());
				ps.setInt(++index, device.getDeviceId());
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void updateDateRepair(int deviceId, String repairDate) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"UPDATE device SET repair_date = ? ");
				sqlCommand.append("WHERE dv_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, repairDate);
				ps.setInt(++index, deviceId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	public void deleteDevice(int deviceId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM device ");
				sqlCommand.append("WHERE dv_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void fixStatusDevice(int deviceId, int status) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("UPDATE device SET status = ? ");
				sqlCommand.append("WHERE dv_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, status);
				ps.setInt(++index, deviceId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	/**
	 * Lấy câu query OrderBy
	 * 
	 * @param String sortType - column được ưu tiên sort trước
	 * @param String sortByFullName - kiểu sort của fullName
	 * @param String sortByCodeLevel - kiểu sort của fullName
	 * @param String sortByEndDate - kiểu sort của fullName
	 * @return String - câu query OrderBy
	 */

	public String getQueryOrderBy(String sortType, String sortByFullName, String sortByCodeLevel,
			String sortByEndDate) {
		// Chuỗi StringBuilder chứa câu truy vấn
		StringBuilder sqlCommand = new StringBuilder();
		// Chia điều kiện sort ưu tiên
		switch (sortType) {
		// ưu tiên theo full_name
		case Constants.FULLNAME:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo code_level
		case Constants.CODE_LEVEL:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo end_date
		case Constants.END_DATE:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("dj.end_date " + sortByEndDate);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			break;
		}
		// Trả về câu query dạng String
		return sqlCommand.toString();
	}
}
