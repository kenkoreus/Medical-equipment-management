/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.DeviceType;

/**
 * [Implement MstGroupDao để Xử lý Thao tác với DB bảng mst_group ]
 *
 * @author namlh
 *
 */
public class DeviceTypeDaoImpl extends BaseDaoImpl {

	public List<DeviceType> getListDeviceTypes(int limit, int offset) throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<DeviceType> listDeviceTypes = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_type_id, dv_type_name, dv_group FROM device_type ");
				sqlCommand.append("LIMIT ? OFFSET ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					DeviceType deviceType = new DeviceType();
					deviceType.setDeviceTypeId(rs.getInt("dv_type_id"));
					deviceType.setDeviceTypeName(rs.getString("dv_type_name"));
					deviceType.setDeviceGroup(rs.getString("dv_group"));
					// Add MstGroup vào listGroups
					listDeviceTypes.add(deviceType);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listDeviceTypes;
	}

	public List<DeviceType> getAllDeviceTypes() throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<DeviceType> listDeviceTypes = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_type_id, dv_type_name, dv_group FROM device_type ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					DeviceType deviceType = new DeviceType();
					deviceType.setDeviceTypeId(rs.getInt("dv_type_id"));
					deviceType.setDeviceTypeName(rs.getString("dv_type_name"));
					deviceType.setDeviceGroup(rs.getString("dv_group"));
					// Add MstGroup vào listGroups
					listDeviceTypes.add(deviceType);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listDeviceTypes;
	}

	public String getDeviceTypeNameById(int deviceTypeId) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		String deviceTypeName = "";
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_type_name FROM device_type WHERE dv_type_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setInt(++index, deviceTypeId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// lấy giá trị groupName
					deviceTypeName = rs.getString("dv_type_name");
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return deviceTypeName;
	}

	public boolean checkExistDeviceType(String deviceTypeName) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		boolean check = false;
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_type_name FROM deviceType WHERE dv_type_name = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setString(++index, deviceTypeName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					check = true;
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return check;
	}

	public boolean insertDeviceType(DeviceType deviceType) throws ClassNotFoundException, SQLException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("INSERT INTO device_type(dv_type_name, dv_group) ");
				sqlCommand.append("VALUES (?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, deviceType.getDeviceTypeName());
				ps.setString(++index, deviceType.getDeviceGroup());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	/**
	 * @param deviceTypeId
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public DeviceType getDeviceTypeById(int deviceTypeId) throws ClassNotFoundException, SQLException {
		DeviceType deviceType = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT dv_type_name, dv_group FROM device_type ");
				sqlCommand.append("WHERE dv_type_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceTypeId);
				rs = ps.executeQuery();
				while (rs.next()) {
					deviceType = new DeviceType();
					deviceType.setDeviceTypeId(deviceTypeId);
					deviceType.setDeviceTypeName(rs.getString("dv_type_name"));
					deviceType.setDeviceGroup(rs.getString("dv_group"));
				}

			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return deviceType;
	}

	public void updateDeviceType(DeviceType deviceType) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("UPDATE device_type SET dv_type_name = ?, dv_group = ? ");
				sqlCommand.append("WHERE dv_type_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, deviceType.getDeviceTypeName());
				ps.setString(++index, deviceType.getDeviceGroup());
				ps.setInt(++index, deviceType.getDeviceTypeId());
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteUserWithDeviceType(int deviceTypeId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM user ");
				sqlCommand.append("WHERE deviceType_id = ?; ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceTypeId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteDeviceType(int deviceTypeId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM deviceType ");
				sqlCommand.append("WHERE deviceType_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, deviceTypeId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
}
