/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Department;
import medical.entities.Provider;

/**
 * [Implement MstGroupDao để Xử lý Thao tác với DB bảng mst_group ]
 *
 * @author namlh
 *
 */
public class ProviderDaoImpl extends BaseDaoImpl {

	public int getTotalProviders() throws SQLException, ClassNotFoundException {
		int totalRecords = 0;
		try {
			if (connectDB()) {
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT COUNT(provider_id) AS total_provider FROM provider ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					totalRecords = rs.getInt("total_provider");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return totalRecords;
	}

	public List<Provider> getAllProviders(int limit, int offset) throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<Provider> listProviders = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT provider_id, provider_name, address, representator, mobile, email FROM provider ");
				sqlCommand.append("LIMIT ? OFFSET ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					Provider provider = new Provider();
					provider.setProviderId(rs.getInt("provider_id"));
					provider.setProviderName(rs.getString("provider_name"));
					provider.setAddress(rs.getString("address"));
					provider.setRepresentator(rs.getString("representator"));
					provider.setMobile(rs.getString("mobile"));
					provider.setEmail(rs.getString("email"));
					// Add MstGroup vào listGroups
					listProviders.add(provider);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listProviders;
	}

	public List<Provider> getAllProviders() throws ClassNotFoundException, SQLException {
		// Khởi tại listGroups chứa các đối tượng MstGroup
		List<Provider> listProviders = new ArrayList<>();
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT provider_id, provider_name FROM provider ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					Provider provider = new Provider();
					provider.setProviderId(rs.getInt("provider_id"));
					provider.setProviderName(rs.getString("provider_name"));
					// Add MstGroup vào listGroups
					listProviders.add(provider);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally { // Đóng kết nối tới DB
			closeConnection();
		}
		// Trả về listGroups
		return listProviders;
	}

	public String getProviderNameById(int providerId) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		String providerName = "";
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT provider_name FROM provider WHERE provider_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setInt(++index, providerId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// lấy giá trị groupName
					providerName = rs.getString("provider_name");
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return providerName;
	}

	public boolean checkExistProvider(String providerName) throws ClassNotFoundException, SQLException {
		// Khởi tạo biến groupName
		boolean check = false;
		try {
			// Kết nối tới DB
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT provider_name FROM provider WHERE provider_name = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// set param cho groupId
				ps.setString(++index, providerName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					check = true;
				}
			}
		} catch (SQLException se) { // Ghi log và ném lỗi nếu xảy ra ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng kết nối tới DB
			closeConnection();
		}
		// trả về biến check tồn tại
		return check;
	}

	public boolean insertProvider(Provider provider) throws ClassNotFoundException, SQLException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("INSERT INTO provider(provider_name, address, mobile, email ) ");
				sqlCommand.append("VALUES (?, ?, ?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, provider.getProviderName());
				ps.setString(++index, provider.getAddress());
				ps.setString(++index, provider.getMobile());
				ps.setString(++index, provider.getEmail());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	/**
	 * @param providerId
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Provider getProviderById(int providerId) throws ClassNotFoundException, SQLException {
		Provider provider = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT provider_name, address, mobile, email FROM provider ");
				sqlCommand.append("WHERE provider_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, providerId);
				rs = ps.executeQuery();
				while (rs.next()) {
					provider = new Provider();
					provider.setProviderId(providerId);
					provider.setProviderName(rs.getString("provider_name"));
					provider.setAddress(rs.getString("address"));
					provider.setMobile(rs.getString("mobile"));
					provider.setEmail(rs.getString("email"));
				}

			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return provider;
	}

	public void updateProvider(Provider provider) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("UPDATE provider SET provider_name = ?, address = ?, mobile = ?, email = ? ");
				sqlCommand.append("WHERE provider_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, provider.getProviderName());
				ps.setString(++index, provider.getAddress());
				ps.setString(++index, provider.getMobile());
				ps.setString(++index, provider.getEmail());
				ps.setInt(++index, provider.getProviderId());
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteDeviceWithProvider(int providerId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM device ");
				sqlCommand.append("WHERE provider_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, providerId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteAccessoryWithProvider(int providerId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM accessory ");
				sqlCommand.append("WHERE provider_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, providerId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
	
	public void deleteProvider(int providerId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM provider ");
				sqlCommand.append("WHERE provider_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, providerId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}
}
