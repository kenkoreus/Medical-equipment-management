/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * TblUserDaoImpl.java, Jul 17, 2019 namlh
 */
package medical.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.User;
import medical.utils.Common;
import medical.utils.Constants;

/**
 * Implement UserDao, thao tác với cơ sở dữ liệu liên quan đến bảng tbl_user
 *
 * @author namlh
 *
 */
public class UserDaoImpl extends BaseDaoImpl {

	public User getUserByLoginName(String loginName) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, role ");
				sqlCommand.append("FROM user WHERE login_name = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, loginName);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setRole(rs.getInt("role"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public User getUserByLoginName(String loginName, int rule) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT login_name, password, salt FROM user ");
				sqlCommand.append("WHERE login_name = BINARY ? AND role = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				ps.setString(++index, loginName);
				ps.setInt(++index, rule);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setLoginName(rs.getString("login_name"));
					user.setPassword(rs.getString("password"));
					user.setSalt(rs.getString("salt"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public int getTotalUsers(int departmentId, String fullName) throws SQLException, ClassNotFoundException {
		int totalRecords = 0;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT COUNT(user_id) AS total_user FROM user u ");
				sqlCommand.append("INNER JOIN department d ON u.department_id = d.department_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có chọn groupId
				if (departmentId != 0) {
					sqlCommand.append("AND d.department_id = ? ");
				}
				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(fullName)) {
					sqlCommand.append("AND u.full_name like ? ");
				}
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());

				// Set param

				if (departmentId != 0) {
					ps.setInt(++index, departmentId);
				}
				if (!fullName.isEmpty()) {
					ps.setString(++index, "%" + fullName + "%");
				}
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					totalRecords = rs.getInt("total_user");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return totalRecords;
	}

	public List<User> getListUsers(int offset, int limit, int departmentId, String fullName, String sortByFullName)
			throws SQLException, ClassNotFoundException {
		List<User> listUsers = new ArrayList<>();
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT u.user_id, u.full_name, u.email, d.department_name, u.mobile, u.address, u.role ");
				sqlCommand.append("FROM user u ");
				sqlCommand.append("INNER JOIN department d ON u.department_id = d.department_id ");
				sqlCommand.append("WHERE 1 = 1 ");

				// Nếu có chọn department
				if (departmentId != 0) {
					sqlCommand.append("AND d.department_id = ? ");
				}
				// Nếu có nhập fullName
				if (!Common.checkIsEmpty(fullName)) {
					sqlCommand.append("AND u.full_name like ? ");
				}

				sqlCommand.append("ORDER BY ");
				sqlCommand.append("u.full_name " + sortByFullName);

				sqlCommand.append(" LIMIT ? OFFSET ?");

				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());

				// set param
				if (departmentId != 0) {
					ps.setInt(++index, departmentId);
				}
				if (!Common.checkIsEmpty(fullName)) {
					ps.setString(++index, "%" + fullName + "%");
				}
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					User user = new User();
					user.setUserId(rs.getInt("user_id"));
					user.setRole(rs.getInt("role"));
					user.setFullName(rs.getString("full_name"));
					user.setMobile(rs.getString("mobile"));
					user.setAddress(rs.getString("address"));
					user.setEmail(rs.getString("email"));
					user.setDepartmentName(rs.getString("department_name"));
					listUsers.add(user);
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return listUsers;
	}

	public User getUserById(int userId) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append(
						"SELECT u.user_id, u.full_name, u.email, d.department_name, u.department_id, u.mobile, u.address, u.login_name ");
				sqlCommand.append("FROM user u ");
				sqlCommand.append("INNER JOIN department d ON u.department_id = d.department_id ");
				sqlCommand.append("WHERE u.user_id = ? ");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, userId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					// Khởi tạo đối tượng UserInfor
					user = new User();
					// Set các giá trị từ đối tượng ResultSet cho UserInfor
					user.setUserId(rs.getInt("user_id"));
					user.setLoginName(rs.getString("login_name"));
					user.setDepartmentId(rs.getInt("department_id"));
					user.setDepartmentName(rs.getString("department_name"));
					user.setFullName(rs.getString("full_name"));
					user.setEmail(rs.getString("email"));
					user.setMobile(rs.getString("mobile"));
					user.setAddress(rs.getString("address"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public User getUserByEmail(String email) throws SQLException, ClassNotFoundException {
		User user = null;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT user_id, email ");
				sqlCommand.append("FROM user WHERE email = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, email);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					user = new User();
					user.setUserId(rs.getInt("user_id"));
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return user;
	}

	public int getRuleByUserId(int userId) throws SQLException, ClassNotFoundException {
		int rule = 0;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("SELECT role FROM user ");
				sqlCommand.append("WHERE user_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, userId);
				// Thực thi câu truy vấn trả kết quả về cho đối tượng ResultSet
				rs = ps.executeQuery();
				while (rs.next()) {
					rule = rs.getInt("role");
				}
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return rule;
	}

	public boolean insertUser(User user) throws SQLException, ClassNotFoundException {
		boolean insert = false;
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("INSERT INTO user(full_name, password, login_name, ");
				sqlCommand.append("email, mobile, address, department_id, role, salt )");
				sqlCommand.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setString(++index, user.getFullName());
				ps.setString(++index, user.getPassword());
				ps.setString(++index, user.getLoginName());
				ps.setString(++index, user.getEmail());
				ps.setString(++index, user.getMobile());
				ps.setString(++index, user.getAddress());
				ps.setInt(++index, user.getDepartmentId());
				ps.setInt(++index, user.getRole());
				ps.setString(++index, user.getSalt());
				ps.executeUpdate();
				insert = true;
			}
		} catch (SQLException se) {
			insert = false;
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
		return insert;
	}

	public void updateUser(User user) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("UPDATE user SET department_id = ?, full_name = ?, ");
				sqlCommand.append("address = ?, email = ?, mobile = ? ");
				sqlCommand.append("WHERE user_id = ? AND role = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, user.getDepartmentId());
				ps.setString(++index, user.getFullName());
				ps.setString(++index, user.getAddress());
				ps.setString(++index, user.getEmail());
				ps.setString(++index, user.getMobile());
				ps.setInt(++index, user.getUserId());
				ps.setInt(++index, Constants.RULE_USER);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	public void deleteUser(int userId) throws SQLException, ClassNotFoundException {
		try {
			if (connectDB()) {
				// Biến index để setParam trong câu sql
				int index = 0;
				// Chuỗi StringBuilder chứa câu truy vấn
				StringBuilder sqlCommand = new StringBuilder();
				sqlCommand.append("DELETE FROM user ");
				sqlCommand.append("WHERE user_id = ?");
				// Khởi tạo đối tượng PrepareStatement truyền vào câu truy vấn
				ps = conn.prepareStatement(sqlCommand.toString());
				// Set param
				ps.setInt(++index, userId);
				ps.executeUpdate();
			}
		} catch (SQLException se) {
			// Ghi log và ném ngoại lệ
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + se.getMessage());
			throw se;
		} finally {
			// Đóng Connection
			closeConnection();
		}
	}

	/**
	 * Lấy câu query OrderBy
	 * 
	 * @param String sortType - column được ưu tiên sort trước
	 * @param String sortByFullName - kiểu sort của fullName
	 * @param String sortByCodeLevel - kiểu sort của fullName
	 * @param String sortByEndDate - kiểu sort của fullName
	 * @return String - câu query OrderBy
	 */

	public String getQueryOrderBy(String sortType, String sortByFullName, String sortByCodeLevel,
			String sortByEndDate) {
		// Chuỗi StringBuilder chứa câu truy vấn
		StringBuilder sqlCommand = new StringBuilder();
		// Chia điều kiện sort ưu tiên
		switch (sortType) {
		// ưu tiên theo full_name
		case Constants.FULLNAME:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo code_level
		case Constants.CODE_LEVEL:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("j.code_level " + sortByCodeLevel);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "dj.end_date " + sortByEndDate);
			break;
		// ưu tiên theo end_date
		case Constants.END_DATE:
			sqlCommand.append("ORDER BY ");
			sqlCommand.append("dj.end_date " + sortByEndDate);
			sqlCommand.append("," + "u.full_name " + sortByFullName);
			sqlCommand.append("," + "j.code_level " + sortByCodeLevel);
			break;
		}
		// Trả về câu query dạng String
		return sqlCommand.toString();
	}
}
