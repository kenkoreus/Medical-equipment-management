/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroup.java, Jul 17, 2019 namlh
 */
package medical.entities;

/**
 * [Bean chứa các thuộc tính của bảng mst_group trong db]
 *
 * @author namlh
 *
 */
public class Department {
	private int departmentId;
	private String departmentName;
	private String address;
	
	public Department() {
		super();
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
