/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * TblUser.java, Jul 17, 2019 namlh
 */
package medical.entities;

/**
 * [Bean chứa các thuộc tính của bảng tbl_user trong db]
 *
 * @author namlh
 *
 */
public class DeviceAccessory {
	private int accessoryId;
	private String accessoryName;
	private int providerId;
	private String providerName;
	private int number;
	private String size;
	private String importDate;
	private int status;

	public DeviceAccessory() {
		super();
	}

	public int getAccessoryId() {
		return accessoryId;
	}

	public void setAccessoryId(int accessoryId) {
		this.accessoryId = accessoryId;
	}

	public String getAccessoryName() {
		return accessoryName;
	}

	public void setAccessoryName(String accessoryName) {
		this.accessoryName = accessoryName;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getImportDate() {
		return importDate;
	}

	public void setImportDate(String importDate) {
		this.importDate = importDate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}