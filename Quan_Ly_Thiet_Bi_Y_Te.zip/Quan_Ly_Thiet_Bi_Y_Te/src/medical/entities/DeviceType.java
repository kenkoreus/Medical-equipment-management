/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroup.java, Jul 17, 2019 namlh
 */
package medical.entities;

/**
 * [Bean chứa các thuộc tính của bảng mst_group trong db]
 *
 * @author namlh
 *
 */
public class DeviceType {
	private int deviceTypeId;
	private String deviceTypeName;
	private String deviceGroup;
	
	public DeviceType() {
		super();
	}

	public int getDeviceTypeId() {
		return deviceTypeId;
	}

	public void setDeviceTypeId(int deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}

	public String getDeviceTypeName() {
		return deviceTypeName;
	}

	public void setDeviceTypeName(String deviceTypeName) {
		this.deviceTypeName = deviceTypeName;
	}

	public String getDeviceGroup() {
		return deviceGroup;
	}

	public void setDeviceGroup(String deviceGroup) {
		this.deviceGroup = deviceGroup;
	}

}
