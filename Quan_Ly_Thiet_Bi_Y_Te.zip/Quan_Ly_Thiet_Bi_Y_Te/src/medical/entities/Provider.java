/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroup.java, Jul 17, 2019 namlh
 */
package medical.entities;

/**
 * [Bean chứa các thuộc tính của bảng mst_group trong db]
 *
 * @author namlh
 *
 */
public class Provider {
	private int providerId;
	private String providerName;
	private String address;
	private String representator;
	private String mobile;
	private String email;

	public Provider() {
		super();
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRepresentator() {
		return representator;
	}

	public void setRepresentator(String representator) {
		this.representator = representator;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
