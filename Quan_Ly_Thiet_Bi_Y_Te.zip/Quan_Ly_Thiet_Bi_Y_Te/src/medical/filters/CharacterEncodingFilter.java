/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * CharacterEncodingFilter.java, Sep 6, 2019, namlh 
 */
package medical.filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import medical.utils.Constants;

/**
 * 
 * CharacterEncodingFilter: encoding request cho các servlet
 *
 * @author namlh
 *
 */
public class CharacterEncodingFilter implements Filter {

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// setCharacterEncoding = UTF-8
		request.setCharacterEncoding(Constants.CHARACTER_ENDCODING);
		// cho qua filter
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}
}
