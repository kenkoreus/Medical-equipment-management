/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * TblUserLogicImpl.java, Jul 17, 2019 namlh
 */
package medical.logics;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import medical.dao.AccessoryDaoImpl;
import medical.dao.DeviceDaoImpl;
import medical.entities.Accessory;
import medical.entities.Device;
import medical.entities.User;
import medical.utils.Common;
import medical.utils.Constants;

/**
 * Implement UserLogic để Xử lý logic cho các chức năng liên quan đến tbl_user
 *
 * @author namlh
 *
 */
public class AccessoryLogicImpl {
	AccessoryDaoImpl accessoryDaoImpl = new AccessoryDaoImpl();

	public boolean checkExistAccount(String loginName, String password, int rule)
			throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean check = false;
		// Lấy user có rule là admin theo login_name
		User user = accessoryDaoImpl.getUserByLoginName(loginName, rule);
		// Nếu account có tồn tại
		if (user != null) {
			// Mã hóa password
			String passwordEncrypt = Common.encryptPassword(password, user.getSalt());
			// Kiểm tra so sánh password vừa mã hóa với password của admin lấy được
			check = Common.compareString(passwordEncrypt, user.getPassword());
		}
		return check;
	}

	public int getTotalAccessories(int providerId, String accessoryName)
			throws SQLException, ClassNotFoundException {
		// Replace kí tự wildcard cho fullName
		accessoryName = Common.replaceWildCard(accessoryName);
		// Lấy về tổng số bản ghi user
		int totalRecords = accessoryDaoImpl.getTotalAccessories(providerId, accessoryName);
		// Trả về tổng số bản ghi lấy được
		return totalRecords;
	}

	public List<Accessory> getListAccessories(int offset, int limit, int providerId, String accessoryName,
			String sortByDeviceName) throws SQLException, ClassNotFoundException {
		// Replace kí tự wildcard cho fullName
		accessoryName = Common.replaceWildCard(accessoryName);
		// Gọi method getListUsers() trả về listUserInfor
		List<Accessory> listAccessories = accessoryDaoImpl.getListDevices(offset, limit, providerId, accessoryName,
				sortByDeviceName);
		// Trả về listUserInfor
		return listAccessories;
	}

	public Accessory getAccessoryById(int accessoryId) throws SQLException, ClassNotFoundException {
		// Gọi getUserInforByUserId bên DAO trả về 1 UserInfor
		Accessory accessory = accessoryDaoImpl.getAccessoryById(accessoryId);
		// Trả về userInfor
		return accessory;
	}

	public boolean checkExistLoginName(String loginName) throws SQLException, ClassNotFoundException {
		boolean check = false;
		// Lấy tblUser theo loginName
		User user = accessoryDaoImpl.getUserByLoginName(loginName);
		// Nếu đã tồn tại user có loginName này trong DB thì check = true;
		if (user != null) {
			check = true;
		}
		return check;
	}

	public boolean checkExistEmail(String email) throws SQLException, ClassNotFoundException {
		boolean check = false;
		// Lấy tblUser theo email
		User user = accessoryDaoImpl.getUserByEmail(email);
		// Nếu đã tồn tại user có email này trong DB thì check = true;
		if (user != null) {
			check = true;
		}
		return check;
	}

	public boolean checkExistEmail(String email, int userId) throws SQLException, ClassNotFoundException {
		boolean check = false;
		// Lấy tblUser theo email
		User user = accessoryDaoImpl.getUserByEmail(email);
		// Nếu đã tồn tại user có email này trong DB thì check = true;
		if (user != null && user.getUserId() != userId) {
			check = true;
		}
		return check;
	}

	public boolean checkExistAccessory(int accessoryId) throws ClassNotFoundException, SQLException {
		return accessoryDaoImpl.checkExistAccessoryById(accessoryId);
	}

	public boolean createAccessory(Accessory accessory) throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean create = accessoryDaoImpl.insertAccessory(accessory);
		return create;
	}

	public boolean updateAccessory(Accessory accessory) throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean update = false;
		// Thực hiện update user
		accessoryDaoImpl.updateAccessory(accessory);
		update = true;
		// Trả về biến update
		return update;
	}

	public boolean deleteAccessory(int accessoryId) throws SQLException, ClassNotFoundException {
		boolean delete = false;
		// Thực hiện delete user
		accessoryDaoImpl.deleteAccessory(accessoryId);
		delete = true;
		// Trả về biến delete
		return delete;
	}

}
