/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupLogicImpl.java, Jul 17, 2019 namlh
 */
package medical.logics;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import medical.dao.DepartmentDaoImpl;
import medical.entities.Department;

/**
 * [Implement MstGroupLogic để Xử lý logic cho các chức năng liên quan đến
 * mst_group]
 *
 * @author namlh
 *
 */
public class DepartmentLogicImpl {
	DepartmentDaoImpl departmentDaoImpl = new DepartmentDaoImpl();

	public int getTotalDepartments() throws SQLException, ClassNotFoundException {
		return departmentDaoImpl.getTotalDepartments();
	}

	public List<Department> getAllDepartments(int limit, int offset) throws ClassNotFoundException, SQLException {
		return departmentDaoImpl.getAllDepartments(limit, offset);
	}

	public List<Department> getAllDepartments() throws ClassNotFoundException, SQLException {
		return departmentDaoImpl.getAllDepartments();
	}

	public boolean checkExistDepartment(int departmentId) throws ClassNotFoundException, SQLException {
		boolean check = false;
		// Lấy về groupName theo groupId
		String departmentName = departmentDaoImpl.getDepartmentNameById(departmentId);
		// Nếu tồn tại groupName
		if (!departmentName.isEmpty()) {
			check = true;
		}
		return check;
	}

	public boolean checkExistDepartment(String departmentName) throws ClassNotFoundException, SQLException {
		return departmentDaoImpl.checkExistDepartment(departmentName);
	}

	public String getDepartmentNameById(int departmentId) throws ClassNotFoundException, SQLException {
		// Lấy về groupName theo groupId
		String departmentName = departmentDaoImpl.getDepartmentNameById(departmentId);
		return departmentName;
	}

	public boolean createDepartment(Department department) throws ClassNotFoundException, SQLException {
		return departmentDaoImpl.insertDepartment(department);
	}

	/**
	 * @param departmentId
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Department getDepartmentById(int departmentId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return departmentDaoImpl.getDepartmentById(departmentId);
	}

	public boolean updateDepartment(Department department)
			throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean update = false;
		// Thực hiện update user
		departmentDaoImpl.updateDepartment(department);
		update = true;
		// Trả về biến update
		return update;
	}

	public boolean deleteDepartment(int departmentId) throws SQLException, ClassNotFoundException {
		boolean delete = false;
		// Thực hiện delete user
		departmentDaoImpl.deleteUserWithDepartment(departmentId);
		departmentDaoImpl.deleteDepartment(departmentId);
		delete = true;
		// Trả về biến delete
		return delete;
	}
}
