/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupLogicImpl.java, Jul 17, 2019 namlh
 */
package medical.logics;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import medical.dao.DeviceTypeDaoImpl;
import medical.entities.DeviceType;

/**
 * [Implement MstGroupLogic để Xử lý logic cho các chức năng liên quan đến
 * mst_group]
 *
 * @author namlh
 *
 */
public class DeviceTypeLogicImpl {
	DeviceTypeDaoImpl deviceTypeDaoImpl = new DeviceTypeDaoImpl();

	public List<DeviceType> getListDeviceTypes(int limit, int offset) throws ClassNotFoundException, SQLException {
		return deviceTypeDaoImpl.getListDeviceTypes(limit, offset);
	}

	public List<DeviceType> getAllDeviceTypes() throws ClassNotFoundException, SQLException {
		return deviceTypeDaoImpl.getAllDeviceTypes();
	}

	public boolean checkExistDeviceType(int deviceTypeId) throws ClassNotFoundException, SQLException {
		boolean check = false;
		// Lấy về groupName theo groupId
		String deviceTypeName = deviceTypeDaoImpl.getDeviceTypeNameById(deviceTypeId);
		// Nếu tồn tại groupName
		if (!deviceTypeName.isEmpty()) {
			check = true;
		}
		return check;
	}

	public boolean checkExistDeviceType(String deviceTypeName) throws ClassNotFoundException, SQLException {
		return deviceTypeDaoImpl.checkExistDeviceType(deviceTypeName);
	}

	public String getDeviceTypeNameById(int deviceTypeId) throws ClassNotFoundException, SQLException {
		// Lấy về groupName theo groupId
		String deviceTypeName = deviceTypeDaoImpl.getDeviceTypeNameById(deviceTypeId);
		return deviceTypeName;
	}

	public boolean createDeviceType(DeviceType deviceType) throws ClassNotFoundException, SQLException {
		return deviceTypeDaoImpl.insertDeviceType(deviceType);
	}

	/**
	 * @param deviceTypeId
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public DeviceType getDeviceTypeById(int deviceTypeId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return deviceTypeDaoImpl.getDeviceTypeById(deviceTypeId);
	}

	public boolean updateDeviceType(DeviceType deviceType)
			throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean update = false;
		// Thực hiện update user
		deviceTypeDaoImpl.updateDeviceType(deviceType);
		update = true;
		// Trả về biến update
		return update;
	}

	public boolean deleteDeviceType(int deviceTypeId) throws SQLException, ClassNotFoundException {
		boolean delete = false;
		// Thực hiện delete user
		deviceTypeDaoImpl.deleteUserWithDeviceType(deviceTypeId);
		deviceTypeDaoImpl.deleteDeviceType(deviceTypeId);
		delete = true;
		// Trả về biến delete
		return delete;
	}
}
