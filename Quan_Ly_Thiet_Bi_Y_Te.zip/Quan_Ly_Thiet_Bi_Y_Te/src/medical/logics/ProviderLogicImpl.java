/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * MstGroupLogicImpl.java, Jul 17, 2019 namlh
 */
package medical.logics;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import medical.dao.ProviderDaoImpl;
import medical.entities.Department;
import medical.entities.Provider;

/**
 * [Implement MstGroupLogic để Xử lý logic cho các chức năng liên quan đến
 * mst_group]
 *
 * @author namlh
 *
 */
public class ProviderLogicImpl {
	ProviderDaoImpl providerDaoImpl = new ProviderDaoImpl();

	public int getTotalProviders() throws SQLException, ClassNotFoundException {
		return providerDaoImpl.getTotalProviders();
	}

	public List<Provider> getAllProviders(int limit, int offset) throws ClassNotFoundException, SQLException {
		return providerDaoImpl.getAllProviders(limit, offset);
	}

	public List<Provider> getAllProviders() throws ClassNotFoundException, SQLException {
		return providerDaoImpl.getAllProviders();
	}

	public boolean checkExistProvider(int providerId) throws ClassNotFoundException, SQLException {
		boolean check = false;
		// Lấy về groupName theo groupId
		String providerName = providerDaoImpl.getProviderNameById(providerId);
		// Nếu tồn tại groupName
		if (!providerName.isEmpty()) {
			check = true;
		}
		return check;
	}

	public boolean checkExistProvider(String providerName) throws ClassNotFoundException, SQLException {
		return providerDaoImpl.checkExistProvider(providerName);
	}

	public String getProviderNameById(int providerId) throws ClassNotFoundException, SQLException {
		// Lấy về groupName theo groupId
		String providerName = providerDaoImpl.getProviderNameById(providerId);
		return providerName;
	}

	public boolean createProvider(Provider provider) throws ClassNotFoundException, SQLException {
		return providerDaoImpl.insertProvider(provider);
	}

	/**
	 * @param providerId
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Provider getProviderById(int providerId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return providerDaoImpl.getProviderById(providerId);
	}

	public boolean updateProvider(Provider provider)
			throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		boolean update = false;
		// Thực hiện update user
		providerDaoImpl.updateProvider(provider);
		update = true;
		// Trả về biến update
		return update;
	}

	public boolean deleteProvider(int providerId) throws SQLException, ClassNotFoundException {
		boolean delete = false;
		// Thực hiện delete user
		providerDaoImpl.deleteDeviceWithProvider(providerId);
		providerDaoImpl.deleteAccessoryWithProvider(providerId);
		providerDaoImpl.deleteProvider(providerId);
		delete = true;
		// Trả về biến delete
		return delete;
	}
}
