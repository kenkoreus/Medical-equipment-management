/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * UserValidate.java, Jul 17, 2019 namlh
 */
package medical.validates;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Device;
import medical.entities.User;
import medical.logics.UserLogicImpl;
import medical.utils.Common;
import medical.utils.Constants;
import medical.utils.MessageProperties;

/**
 * Validate(xác thực) các hạng mục liên quan đến User
 *
 * @author namlh
 *
 */
public class DeviceValidate {

	/**
	 * Validate account đăng nhập
	 * 
	 * @param loginName - tên đăng nhập
	 * @param password  - mật khẩu
	 * @return listErrorMess - list chứa các câu thông báo validate
	 * @throws SQLException             - Ngoại lệ SQLException
	 * @throws ClassNotFoundException   - Ngoại lệ ClassNotFoundException
	 * @throws NullPointerException     - Ngoại lệ NullPointerException
	 * @throws NoSuchAlgorithmException - Ngoại lệ NoSuchAlgorithmException
	 */
	public List<String> validateLogin(String loginName, String password)
			throws SQLException, ClassNotFoundException, NullPointerException, NoSuchAlgorithmException {
		// Khai báo danh sách chứa câu thông báo validate
		List<String> listErrorMess = new ArrayList<>();
		// Nếu không nhập loginName
		if (Common.checkIsEmpty(loginName)) {
			// Add câu thông báo chưa nhập loginName
			listErrorMess.add(MessageProperties.getMessage(Constants.ER001_LOGIN_NAME));
		}
		// Nếu không nhập password
		if (Common.checkIsEmpty(password)) {
			// Add câu thông báo chưa nhập password
			listErrorMess.add(MessageProperties.getMessage(Constants.ER001_PASSWORD));
		}
		// Nếu đã nhập cả hai hạng mục
		if (listErrorMess.size() == 0) {
			// Khởi tạo TblUserLogic
			UserLogicImpl userLogicImpl = new UserLogicImpl();
			// Nếu account không tồn tại trong DB
			if (!userLogicImpl.checkExistAccount(loginName, password, Constants.RULE_ADMIN)) {
				// Add câu thông báo tên tài khoản và mật khẩu không đúng
				listErrorMess.add(MessageProperties.getMessage(Constants.ER016_ACCOUNT_LOGIN));
			}
		}
		// Trả về listErrorMess
		return listErrorMess;
	}

	/**
	 * Validate các hạng mục ở màn hình ADM003
	 * 
	 * @param device - Đối tượng UserInfor
	 * @return listErrorMess - list chứa các câu thông báo validate
	 * @throws ClassNotFoundException - Ngoại lệ ClassNotFoundException
	 * @throws SQLException           - Ngoại lệ SQLException
	 */
//	public List<String> validateDevice(Device device) throws ClassNotFoundException, SQLException {
//		// Khởi tạo list chứa các câu thông báo validate
//		List<String> listErrorMess = new ArrayList<String>();
//		// Add câu thông báo lỗi sau khi validate hạng mục fullName
//		Common.addStringToList(listErrorMess, validateFullName(device.getFullName()));
//		// Nếu userId = 0(Trường hợp Add mới) thì validate hạng mục loginName
//		if (device.getUserId() == 0) {
//			// Add câu thông báo lỗi sau khi validate hạng mục loginName
//			Common.addStringToList(listErrorMess, validateLoginName(device.getLoginName()));
//		}
//		// Nếu là trường hợp add mới thì validate hạng mục password & passwordConfirm
//		if (device.getUserId() == 0) {
//			// Add câu thông báo lỗi sau khi validate hạng mục password
//			Common.addStringToList(listErrorMess, validatePassword(device.getPassword()));
//		}
//		// Add câu thông báo lỗi sau khi validate hạng mục group
//		Common.addStringToList(listErrorMess, validateDepartment(device.getDepartmentId()));
//		// Add câu thông báo lỗi sau khi validate hạng mục tel
//		Common.addStringToList(listErrorMess, validateTel(device.getMobile()));
//		// Add câu thông báo lỗi sau khi validate hạng mục email
//		Common.addStringToList(listErrorMess, validateEmail(device.getEmail(), device.getUserId()));
//		// Trả về listErrorMess
//		return listErrorMess;
//	}

	/**
	 * Validate hạng mục loginName
	 * 
	 * @param loginName - tên đăng nhập của user
	 * @return String error - thông báo lỗi validate
	 * @throws SQLException           - Ngoại lệ SQLException
	 * @throws ClassNotFoundException - Ngoại lệ ClassNotFoundException
	 */
	public String validateLoginName(String loginName) throws ClassNotFoundException, SQLException {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Khởi tạo đối tượng TblUserLogic
		UserLogicImpl userLogicImpl = new UserLogicImpl();
		// Nếu không nhập loginName
		if (Common.checkIsEmpty(loginName)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER001_LOGIN_NAME);
			// Nếu nhập loginName sai định dạng
		} else if (!Common.checkFormat(loginName, Constants.FORMAT_LOGIN_NAME)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER019);
			// Nếu độ dài loginName không thỏa mãn
		} else if (!Common.checkLengthRange(Constants.MIN_VALUE_LOGIN_NAME, Constants.MAX_VALUE_LOGIN_NAME,
				loginName)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER007_LOGIN_NAME);
			// Nếu loginName đã tồn tại trong DB
		} else if (userLogicImpl.checkExistLoginName(loginName)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER003_LOGIN_NAME);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục Group
	 * 
	 * @param departmentId - Id của nhóm
	 * @return String error - thông báo lỗi validate
	 * @throws SQLException           - Ngoại lệ SQLException
	 * @throws ClassNotFoundException - Ngoại lệ ClassNotFoundException
	 */
	public String validateDepartment(int departmentId) throws ClassNotFoundException, SQLException {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu không chọn group nào
		if (departmentId == 0) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.NO_CHOOSE_DEPARTMENT);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục fullName
	 * 
	 * @param fullName - Tên đầy đủ của user
	 * @return String error - thông báo lỗi
	 */
	public String validateFullName(String fullName) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// check không nhập
		if (Common.checkIsEmpty(fullName)) {
			error = MessageProperties.getMessage(Constants.ER001_FULL_NAME);
			// check vượt quá số kí tự max
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_STRING, fullName)) {
			error = MessageProperties.getMessage(Constants.ER006_FULL_NAME_255);
		}
		// Trả về câu thông báo
		return error;
	}

	public String validateEmpty(String input) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// check không nhập
		if (Common.checkIsEmpty(input)) {
			error = MessageProperties.getMessage("ER001_DEVICE");
			// check vượt quá số kí tự max
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục fullNameKana
	 * 
	 * @param fullNameKana - tên Kana của user
	 * @return String error - thông báo lỗi
	 */
	private String validateFullNameKana(String fullNameKana) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu không null thì check
		if (!Common.checkIsEmpty(fullNameKana)) {
			// check có phải là kí tự katakana
			if (!Common.checkFormat(fullNameKana, Constants.FORMAT_FULL_NAME_KANA)) {
				error = MessageProperties.getMessage(Constants.ER009);
				// check vượt quá số kí tự max
			} else if (!Common.checkMaxLength(Constants.MAX_VALUE_STRING, fullNameKana)) {
				error = MessageProperties.getMessage(Constants.ER006_FULL_NAME_KANA_255);
			}
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục birthDay
	 * 
	 * @param birthDay - Ngày sinh của user
	 * @return String error - thông báo lỗi
	 */
	private String validateBirthDay(String birthDay) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu ngày không hợp lệ
		if (!Common.isDateValid(birthDay)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER011_BIRTH_DAY);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục email
	 * 
	 * @param String email - email user
	 * @param int    userId - id của user
	 * @return String error - thông báo lỗi
	 * @throws SQLException           - Ngoại lệ SQLException
	 * @throws ClassNotFoundException - Ngoại lệ ClassNotFoundException
	 */
	private String validateEmail(String email, int userId) throws ClassNotFoundException, SQLException {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Check không nhập
		if (Common.checkIsEmpty(email)) {
			error = MessageProperties.getMessage(Constants.ER001_EMAIL);
			// Check maxlength
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_EMAIL, email)) {
			error = MessageProperties.getMessage(Constants.ER006_EMAIL_100);
			// Check format
		} else if (!Common.checkFormat(email, Constants.FORMAT_EMAIL)) {
			error = MessageProperties.getMessage(Constants.ER005_EMAIL);
		} else { // check email nhập có tồn tại trong DB hay không
			// Khởi tạo TblUserLogic
			UserLogicImpl userLogicImpl = new UserLogicImpl();
			// userId = 0 (Trường hợp add mới)
			if (userId == 0) {
				// Nếu đã tồn tại email thì lấy câu thông báo email đã tồn tại
				if (userLogicImpl.checkExistEmail(email)) {
					error = MessageProperties.getMessage(Constants.ER003_EMAIL);
				}
			} else { // Trường hợp edit
				// Nếu đã tồn tại email thì lấy câu thông báo email đã tồn tại
				if (userLogicImpl.checkExistEmail(email, userId)) {
					error = MessageProperties.getMessage(Constants.ER003_EMAIL);
				}
			}
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục tel
	 * 
	 * @param tel - số điện thoại của user
	 * @return String error - thông báo lỗi
	 */
	private String validateTel(String tel) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Check không nhập
		if (Common.checkIsEmpty(tel)) {
			error = MessageProperties.getMessage(Constants.ER001_TEL);
			// Check maxlength
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_TEL, tel)) {
			error = MessageProperties.getMessage(Constants.ER006_TEL_14);
			// Check format
		} else if (!Common.checkFormat(tel, Constants.FORMAT_TEL)) {
			error = MessageProperties.getMessage(Constants.ER005_TEL);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục password
	 * 
	 * @param password - mật khẩu của user
	 * @return String error - thông báo lỗi
	 */
	private String validatePassword(String password) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Check không nhập
		if (Common.checkIsEmpty(password)) {
			error = MessageProperties.getMessage(Constants.ER001_PASSWORD);
			// Check trong khoảng
		} else if (!Common.checkLengthRange(Constants.MIN_VALUE_PASSWORD, Constants.MAX_VALUE_PASSWORD, password)) {
			error = MessageProperties.getMessage(Constants.ER007_PASSWORD);
			// Check có phải kí tự 1 byte
		} else if (!Common.checkCharacterHalfSize(password)) {
			error = MessageProperties.getMessage(Constants.ER008_PASSWORD);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục nhập lại password
	 * 
	 * @param passwordConfirm - mật khẩu xác nhận trên form
	 * @return String error - thông báo lỗi
	 */
	private String validatePasswordConfirm(String password, String passwordConfirm) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu passwordConfirm không giống password
		if (!Common.compareString(password, passwordConfirm)) {
			error = MessageProperties.getMessage(Constants.ER017);
		}
		// Trả về câu thông báo
		return error;
	}

	

	/**
	 * Validate hạng mục ngày có hiệu lực
	 * 
	 * @param startDate - ngày có hiệu lực của trình độ tiếng nhật
	 * @return String error - thông báo lỗi
	 */
	private String validateStartDate(String startDate) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu ngày không hợp lệ
		if (!Common.isDateValid(startDate)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER011_START_DATE);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục endDate phải là ngày hợp lệ và phải lớn hơn startDate
	 * 
	 * @param startDate - ngày có hiệu lực của trình độ tiếng nhật
	 * @param endDate   - ngày hết hiệu lực của trình độ tiếng nhật
	 * @return error - câu thông báo lỗi
	 */
	private String validateEndDate(String startDate, String endDate) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu ngày không hợp lệ
		if (!Common.isDateValid(endDate)) {
			error = MessageProperties.getMessage(Constants.ER011_END_DATE);
			// Nếu endDate không lớn hơn endDate
		} else if (!Common.checkEndDateMoreThanStartDate(startDate, endDate)) {
			// Lấy câu thông báo lỗi
			error = MessageProperties.getMessage(Constants.ER012);
		}
		// Trả về câu thông báo
		return error;
	}

	/**
	 * Validate hạng mục tổng điểm
	 * 
	 * @param total - điểm số trình độ tiếng nhật của user
	 * @return String error - thông báo lỗi
	 */
	private String validateTotal(String total) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Nếu không nhập hoặc nhập số 0
		if (Common.checkIsEmpty(total) || "0".equals(total)) {
			error = MessageProperties.getMessage(Constants.ER001_TOTAL);
			// check số halfsize
		} else if (!total.matches(Constants.FORMAT_NUMBER_HALF_SIZE)) {
			error = MessageProperties.getMessage(Constants.ER018);
			// check vượt quá số kí tự max
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_TOTAL, total)) {
			error = MessageProperties.getMessage(Constants.ER006_TOTAL_9);
		}
		// Trả về câu thông báo
		return error;
	}
}
