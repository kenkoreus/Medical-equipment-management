/**
 * Copyright(C) 2019 Luvina Software Company
 *
 * UserValidate.java, Jul 17, 2019 namlh
 */
package medical.validates;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import medical.entities.Provider;
import medical.utils.Common;
import medical.utils.Constants;
import medical.utils.MessageProperties;

/**
 * Validate(xác thực) các hạng mục liên quan đến User
 *
 * @author namlh
 *
 */
public class ProviderValidate {

	/**
	 * Validate các hạng mục ở màn hình ADM003
	 * 
	 * @param user - Đối tượng UserInfor
	 * @return listErrorMess - list chứa các câu thông báo validate
	 * @throws ClassNotFoundException - Ngoại lệ ClassNotFoundException
	 * @throws SQLException           - Ngoại lệ SQLException
	 */
	public List<String> validateProvider(Provider provider) throws ClassNotFoundException, SQLException {
		// Khởi tạo list chứa các câu thông báo validate
		List<String> listErrorMess = new ArrayList<String>();
		// Add câu thông báo lỗi sau khi validate hạng mục providerName
		Common.addStringToList(listErrorMess, validateProviderName(provider.getProviderName()));
		// Add câu thông báo lỗi sau khi validate hạng mục address
		Common.addStringToList(listErrorMess, validateAddress(provider.getAddress()));
		// Add câu thông báo lỗi sau khi validate hạng mục mobile
		Common.addStringToList(listErrorMess, validateMobile(provider.getMobile()));
		// Add câu thông báo lỗi sau khi validate hạng mục email
		Common.addStringToList(listErrorMess, validateEmail(provider.getEmail()));
		return listErrorMess;
	}

	/**
	 * Validate hạng mục fullName
	 * 
	 * @param providerName - Tên đầy đủ của user
	 * @return String error - thông báo lỗi
	 */
	public String validateProviderName(String providerName) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// check không nhập
		if (Common.checkIsEmpty(providerName)) {
			error = MessageProperties.getMessage(Constants.ER001_DEPARTMENT_NAME);
			// check vượt quá số kí tự max
		}
		// Trả về câu thông báo
		return error;
	}

	public String validateAddress(String address) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// check không nhập
		if (Common.checkIsEmpty(address)) {
			error = MessageProperties.getMessage("ER001_ADDRESS");
			// check vượt quá số kí tự max
		}
		// Trả về câu thông báo
		return error;
	}
	
	private String validateEmail(String email) throws ClassNotFoundException, SQLException {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Check không nhập
		if (Common.checkIsEmpty(email)) {
			error = MessageProperties.getMessage(Constants.ER001_EMAIL);
			// Check maxlength
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_EMAIL, email)) {
			error = MessageProperties.getMessage(Constants.ER006_EMAIL_100);
			// Check format
		} else if (!Common.checkFormat(email, Constants.FORMAT_EMAIL)) {
			error = MessageProperties.getMessage(Constants.ER005_EMAIL);
		} 
		// Trả về câu thông báo
		return error;
	}
	
	private String validateMobile(String tel) {
		// Khai báo chuỗi chứa câu thông báo validate
		String error = "";
		// Check không nhập
		if (Common.checkIsEmpty(tel)) {
			error = MessageProperties.getMessage(Constants.ER001_TEL);
			// Check maxlength
		} else if (!Common.checkMaxLength(Constants.MAX_VALUE_TEL, tel)) {
			error = MessageProperties.getMessage(Constants.ER006_TEL_14);
			// Check format
		} else if (!Common.checkFormat(tel, Constants.FORMAT_TEL)) {
			error = MessageProperties.getMessage(Constants.ER005_TEL);
		}
		// Trả về câu thông báo
		return error;
	}
}
